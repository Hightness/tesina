import numpy as np

def switch(a, b):
    return (b, a)

def scambia_nodi(b, c):
    #print(f'scambio nodo {b} con nodo {c}')
    if b > c: b, c = switch(b, c)
    #per scambiare due nodi, visto che li rappresento con una matrice triangolare parto con il
    # nodo piu' piccolo poiche' avra' il minor numero di archi che partono da esso
    #la procedura per scambiare i due nodi consiste nello scambiare nella matrice, le partenze dal nodo piu'
    #piccolo con quello piu' grande, e scambiare le destinazioni che arrivano al nodo piu' grande con quelle
    #che arrivano nel piu' piccolo

    for i in range(b - 1): a[i][c-1], a[i][b-1] = switch(a[i][c-1], a[i][b-1])
    for j in range(len(a) - c): a[c-1][j+c], a[b-1][j+c] = switch(a[c-1][j+c], a[b-1][j+c])

    #caso speciale, i due for qui sopra ciclano 0 volte..
    if c == len(a) and b == 1:#se devo scambiare primo nodo con ultimo, scambio le partenze dell'ultimo nodo
                              #con le destinazioni del primo, e viceversa
        for i in range(len(a) - 2):a[i+1][c-1], a[0][i+1] = switch(a[i+1][c-1],a[0][i+1])




def r_generator(nv, archi, i, j):
    #genera ricorsivamente una matrice triangolare rappresentando con 1 archi random
    #le colonne rappresentano le partenze (es nella colonna 4 abbiamo tutti i nodi destinazione che partono dal nodo 4)
    #le righe invece le destinazioni (es riga 1 abbiamo tutte le partenze che finiscono nel nodo 1)
    if j == nv:return archi
    archi[i][j] = np.random.randint(2)
    i = (i + 1)%j
    j = j + (i == 0)
    return r_generator(nv, archi, i, j)

def check_incroci_arco(P, D):
    partenze = list()
    #controllo che non ci siano archi con partenza (p) minore della partenza dell'arco in questione (P)
    # e maggiore della destinazione dell'arco in questione (D), e con destinazione (d) strettamente minore
    #della destinazione dell'arco in questione (D)

    if a[D][P] == 0:return partenze#se arco non e' presente chiaramente non ci possono essere incroci
    for p in reversed(range(D + 1, P)):  #in realta P-1 ma range finisce -1
        for d in reversed(range(D)):
            if a[d][p] > 0:
                partenze.append(d)
                #print(f'arco({P + 1}, {D + 1}) collide con arco ({p + 1}, {d + 1})')
    return partenze

def r_check_incroci(i, j):
    #per ogni arco, partendo dal maggiore (dest e partenza num grandi), controllo quanti incroci ha
    if i < 0:
        j -= 1
        i = j - 1
    if j == 1: return 0
    return r_check_incroci(i - 1, j) + len(check_incroci_arco(j, i))


nv = 5
n_iterations = 10000/nv
j = 0
cache = np.zeros(shape=(nv, nv))#la cache sara' utile per non scambiare 2 nodi che ho gia' scambiato
scambi_effettuati = list() #utile alla fine per ricostruire gli spostamenti dei nodi
a = r_generator(nv, np.zeros(shape = (nv, nv)), 0, 1)#genero la matrice con gli archi
a_best = a.copy()#in a_best ci salvero' la permutazione del grafo migliore
bn = fn = r_check_incroci(nv - 2, nv - 1)#bn rappresenta il minor numero di intersezioni raggiunta
print(f'num intersezioni: {bn}, matrice:\n{a}\n')

while bn*(n_iterations-j) >= fn and j < n_iterations:#ciclo fin quando bn non e' abbastanza piccolo in confronta alle intersezioni iniziali
    #print(f'new run.. current number of intersections: {bn}\n\n')
    cache = np.zeros(shape=(nv, nv))#riazzero cache per ripermutare i nodi
    i = n1 = n2 = 1
    while r_check_incroci(nv - 2, nv - 1) and i < n_iterations and np.sum(cache) < nv*(nv-1):
        #fin quando non ho provato tutte le possibili permutazioni di nodi(nv*(nv-1)), continuo a prendere 2 nodi
        #randomicamente e scambiarli
        while cache[n1-1][n2-1] == 1 or n1 == n2:
            n1, n2 = np.random.randint(1, nv + 1), np.random.randint(1, nv + 1)
        scambia_nodi(n1, n2)
        cache[n1 - 1][n2 - 1] = 1
        cache[n2 - 1][n1 - 1] = 1
        ni = r_check_incroci(nv - 2, nv - 1)
        if ni < bn:#se nuovo numero di intersezioni minore, salvo lo scambio effettuato e aggiorno a_best
            if n2 < n1:n1, n2 = switch(n1, n2)
            scambi_effettuati.append(f'{n1}:{n2}')
            a_best = a.copy()
            bn = ni
        else:scambia_nodi(n1, n2)#altrimenti riscambio i nodi (tornando alla situazione iniziale)e vado avanti..
        i += 1
    j += 1

a = a_best.copy()
print(f'\nnum intersezioni: {bn}, matrice:\n{a}\n')
print(f'nodi scambiati (in ordine): {scambi_effettuati}')
